package br.edu.ifba.inf008.interfaces;

import br.edu.ifba.inf008.interfaces.ICore;

public interface IPluginController
{
    public abstract boolean init();
}
